package com.skgram.sikkim;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.*;
import android.os.*;
import android.provider.*;
import android.support.annotation.*;
import android.support.v4.*;
import android.support.v7.widget.*;
import android.text.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import com.google.android.gms.tasks.*;
import com.google.firebase.auth.*;
import com.google.firebase.database.*;
import com.google.firebase.storage.*;
import java.util.*;

//import android.support.v4.R;

public class MainPageActivity extends Activity
{
   
 //  public ListView lv;
   private FirebaseDatabase db;
   private DatabaseReference mRef;
   private FirebaseStorage mStorage;
   private StorageReference mStorageRef;
   private ChildEventListener childeventlistner;
   private CustomAdapter adapter;
	private ListView lv;
	public ArrayList<Post> post ;
  public static final int  GALARY_INTENT = 1;
  private String urlphoto;
 	
   @Override
    protected void onCreate(Bundle savedInstanceState)
   {   
   
        // TODO: Implement this method
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_page);
	   lv = (ListView) findViewById(R.id.mainpageListView1);
	ActionBar bar = getActionBar();
       bar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#6200ee")));
       getActionBar().setTitle(Html.fromHtml("<font color='#ffffff'><b>SkGram</b></font>"));
       Window w = this.getWindow();w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
       w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
       w.setStatusBarColor(Color.parseColor("#6200ee"));
      
        mStorage = FirebaseStorage.getInstance();
       mStorageRef = mStorage.getReference();
        db = FirebaseDatabase.getInstance();
       mRef = db.getReference().child("posts");
       
       
     	 post = new ArrayList<>();     
       adapter = new CustomAdapter(this, R.layout.postpage, post);

	   // Now set the layout manager and the adapter to the RecyclerVi
       lv.setAdapter(adapter);
       
       childeventlistner = new ChildEventListener(){

           @Override
           public void onChildAdded(DataSnapshot p1, String p2)
           {
               // TODO: Implement this method
               Post p = p1.getValue(Post.class);
			  	post.add(0,p);
			 	adapter.notifyDataSetChanged();
				//adapter.add(p);
				
			   
           }

           @Override
           public void onChildChanged(DataSnapshot p1, String p2)
           {
               // TODO: Implement this method
           }

           @Override
           public void onChildRemoved(DataSnapshot p1)
           {
               // TODO: Implement this method
           }

           @Override
           public void onChildMoved(DataSnapshot p1, String p2)
           {
               // TODO: Implement this method
           }

           @Override
           public void onCancelled(DatabaseError p1)
           {
               // TODO: Implement this method
           }                  
       };
       mRef.addChildEventListener(childeventlistner);
   }
   
   public void addimage(View view){
	   final Dialog dg = new Dialog(MainPageActivity.this);
	   dg.setContentView(R.layout.choosecamaraorfile);
	   dg.show();
	   dg.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

	  ImageView camBtn =(ImageView) dg.findViewById(R.id.camerabtn);
	   ImageView galleryBtn =(ImageView) dg.findViewById(R.id.gallerybtn);
	   if(camBtn!=null&galleryBtn!=null){
	   galleryBtn.setOnClickListener(new OnClickListener(){
			   @Override
			   public void onClick(View p1)
			   {
				   // TODO: Implement this method
				   dg.hide();
				   Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
				   intent.setType("image/*");
				   intent.putExtra(Intent.EXTRA_LOCAL_ONLY, true);
				   startActivityForResult(intent,GALARY_INTENT );

			   }
		   });
	   camBtn.setOnClickListener(new OnClickListener(){
			   @Override
			   public void onClick(View p1)
			   {
				   // TODO: Implement this method
				   Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
				   startActivityForResult(i,GALARY_INTENT);
				   dg.hide();
			   }                  
		   });       
		   }else{
			   Toast.makeText(this,"",Toast.LENGTH_SHORT).show();
		   }
   }

   @Override
   protected void onActivityResult(int requestCode, int resultCode, Intent data)
   {
       // TODO: Implement this method
       super.onActivityResult(requestCode, resultCode, data);
       if(requestCode == GALARY_INTENT && resultCode==RESULT_OK){
           Uri uri = data.getData();
           /*    try
            {
            Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), uri);    
            imgview.setImageBitmap(bitmap);
            }
            catch (IOException e)
            {}
            */
           final StorageReference filepath = mStorage.getReference("photos").child(uri.getLastPathSegment());
           filepath.putFile(uri).addOnFailureListener(new OnFailureListener() {
                   @Override
                   public void onFailure(@NonNull Exception exception) {
                       // Handle unsuccessful uploads
                   }
               }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                   @Override
                   public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                       // taskSnapshot.getMetadata() contains file metadata such as size, content-type, etc.
                       // ...
                       Toast.makeText(MainPageActivity.this,"task finished",Toast.LENGTH_LONG).show();


                   }
               }).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                   @Override
                   public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                       if (!task.isSuccessful()) {
                           throw task.getException();
                       }

                       // Continue with the task to get the download URL
                       return filepath.getDownloadUrl();
                   }
               }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                   @Override
                   public void onComplete(@NonNull Task<Uri> task) {
                       if (task.isSuccessful()) {
                           Uri downloadUri = task.getResult();
                           

                           String st = downloadUri.toString();
                           urlphoto = st;
                           pushtostorage();


                       } else {
                           // Handle failures
                           // ...
                       }
                   }
               });
      }
   }
         public void pushtostorage(){
             FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

             final String email = user.getEmail();
             Post friendlyMessage = new Post(email, urlphoto);
             mRef.push().setValue(friendlyMessage);
         }
         
    

    @Override
    protected void onPause()
    {
        // TODO: Implement this method
        super.onPause();
       // lv.setTranscriptMode(AdapterView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
        
    }
	private ArrayList<Post> reverseListOrder(ArrayList<Post> post)
	{
		Iterator<Post> it = post.iterator();
		ArrayList<Post> destination = new ArrayList<>();
		while (it.hasNext()) {
			destination.add(0, it.next());
			it.remove();
		}
		return destination;
	}
    
}

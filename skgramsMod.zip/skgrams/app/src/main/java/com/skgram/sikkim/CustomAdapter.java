package com.skgram.sikkim;
import android.app.*;
import android.content.*;
import android.view.*;
import android.widget.*;
import com.bumptech.glide.*;
import java.util.*;
import android.support.v7.widget.*;

public class CustomAdapter extends ArrayAdapter<Post>
{
    public CustomAdapter(Context context, int resource, List<Post> objects) {
        super(context, resource, objects);
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = ((Activity) getContext()).getLayoutInflater().inflate(R.layout.postpage, parent, false);
        }
        ImageView photoImageView =  (ImageView) convertView.findViewById(R.id.postpageImageView1);
        TextView messageTextView =  (TextView) convertView.findViewById(R.id.postpageName);
       // Post message = getItem(position);
        Post message = getItem(position); 
        Glide.with(photoImageView.getContext())
            .load(message.getPhotoUrl())
            .into(photoImageView);
        messageTextView.setText(message.getName());
		
        return convertView;
    }

   
        }

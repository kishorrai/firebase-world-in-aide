package com.skgram.sikkim;

import android.app.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.*;
import android.support.annotation.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import com.google.android.gms.tasks.*;
import com.google.firebase.auth.*;
import android.content.*;
import org.apache.http.auth.*;

public class MainActivity extends Activity 
{
    private TextView showDg;
    private Dialog dg;
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mListner;
    private ProgressDialog pgbar ;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        getActionBar().hide();
        pgbar = new ProgressDialog(MainActivity.this);
       //generate dialog     
       mAuth = FirebaseAuth.getInstance();
        mListner = new FirebaseAuth.AuthStateListener(){

            @Override
            public void onAuthStateChanged(FirebaseAuth p1)
            {
                // TODO: Implement this method
                if(p1.getCurrentUser() != null){
                    Intent i = new Intent(MainActivity.this,MainPageActivity.class);
                    startActivity(i);
                }
            }         
       };
       //authstatelistner start
       
       
       //authstatelistner end
       //start login
        Button btnLogin = (Button) findViewById(R.id.mainLoginBtn);
        btnLogin.setOnClickListener(new OnClickListener(){

                @Override
                public void onClick(View p1)
                {
                    // TODO: Implement this method
                    pgbar.setMessage("please wait...");
                    pgbar.show();
                    EditText em = (EditText) findViewById(R.id.mainEmail);
                    EditText pass = (EditText) findViewById(R.id.mainPassword);
                    
                     String emaillogin = em.getText().toString();
                     String passLogin = pass.getText().toString();

                    if(emaillogin.isEmpty()){
                        pgbar.hide();
                        Toast.makeText(MainActivity.this,"please type valid email",Toast.LENGTH_LONG).show();
                        return;
                    }
                    if(passLogin.length()<6){
                        pgbar.hide();
                        Toast.makeText(MainActivity.this,"passqord is too short",Toast.LENGTH_LONG).show();       
                        return;
                    }
                    
                    
                    mAuth.signInWithEmailAndPassword(emaillogin, passLogin)
                        .addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Sign in success, update UI with the signed-in user's information
                                    Intent i = new Intent(MainActivity.this,MainPageActivity.class);
                                    startActivity(i);
                                } else {
                                    // If sign in fails, display a message to the user.
                                    Toast.makeText(MainActivity.this,"Wrong password or email",Toast.LENGTH_LONG).show();
                                   pgbar.hide();
                                }       

                                // ...
                            }
                        });
                }
                
            
        });
        
       
       //end login
       
        showDg = (TextView) findViewById(R.id.dialogsignup);
        showDg.setOnClickListener(new OnClickListener(){
                @Override
                public void onClick(View p1)
                {
                    
                    
                    // TODO: Implement this method
                    dg = new Dialog(MainActivity.this);
                    dg.setContentView(R.layout.signup);
                    dg.show();
                    dg.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                    ImageView hididedialog = (ImageView) dg.findViewById(R.id.closedialog);
                    hididedialog.setOnClickListener(new OnClickListener(){

                            @Override
                            public void onClick(View p1)
                            {
                                // TODO: Implement this method
                                dg.hide();
                            }       
                        });
                        Button register = (Button) dg.findViewById(R.id.regsterBtn);
                    register.setOnClickListener(new OnClickListener(){

                            @Override
                            public void onClick(View p1)
                            {
                                // TODO: Implement this method
                                pgbar.setMessage("registering please wait...");
                                pgbar.show();
                                
                                EditText emailsignup = (EditText) dg.findViewById(R.id.customemailed);
                                EditText passwordsignup = (EditText) dg.findViewById(R.id.custompassworded);
                                EditText confirmpasswordsignup = (EditText) dg.findViewById(R.id.customconfirmpassworded);
                               final String email = emailsignup.getText().toString();
                               final String password = passwordsignup.getText().toString();
                               final String confirmpassword = confirmpasswordsignup.getText().toString();
                                if(password.length()<6){
                                    pgbar.hide();
                                    Toast.makeText(MainActivity.this,"passqord is too short",Toast.LENGTH_LONG).show();       
                                    
                                    return;
                                }
                                if(email.isEmpty()){
                                    Toast.makeText(MainActivity.this,"please type valid email",Toast.LENGTH_LONG).show();
                                    return;
                                }else if(password.equals(confirmpassword)){
                                    mAuth.createUserWithEmailAndPassword(email, password)
                                        .addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
                                            @Override
                                            public void onComplete(@NonNull Task<AuthResult> task) {
                                                if (task.isSuccessful()) {
                                                    // Sign in success, update UI with the signed-in user's information
                                                    Intent i = new Intent(MainActivity.this,MainPageActivity.class);
                                                    startActivity(i);
                                                } else {
                                                    // If sign in fails, display a message to the user.
                                                    Toast.makeText(MainActivity.this,"you already have account or their is no internet connection.",Toast.LENGTH_LONG).show();
                                                    
                                                }                                                                           } });
                                }else{
                                    pgbar.hide();
                                    Toast.makeText(MainActivity.this,"passqord is not matching",Toast.LENGTH_LONG).show();
                                    return;
                                }                                                                                                         
                            }                          
                        });
                    }           
        });
        
    }

    @Override
    protected void onStart()
    {
        // TODO: Implement this method
        super.onStart();
        mAuth.addAuthStateListener(mListner);
    }
    
}
